from .histograms import histograms, histogram

__all__ = ["histograms", "histogram"]