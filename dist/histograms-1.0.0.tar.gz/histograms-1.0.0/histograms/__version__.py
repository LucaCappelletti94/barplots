"""Current version of package histograms"""
__version__ = "1.0.0"