"""Current version of package barplots"""
__version__ = "1.1.3"
